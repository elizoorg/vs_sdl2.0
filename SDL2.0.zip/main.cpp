#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>

int main(int argc, char** argv){
	SDL_Init(SDL_INIT_EVERYTHING);



	SDL_Quit();
	return 0;
}